VISÃO GERAL DA ARQUITETURA
O backend segue a arquitetura MVC (Model-View-Controller) para organizar o código em camadas lógicas:

models: Define a estrutura dos dados e a comunicação com o banco de dados.

controllers: Contém a lógica de negócio, processando as requisições e interagindo com os modelos.

routes: Gerencia as rotas da API, direcionando as requisições para os controladores.

middlewares: Funções que são executadas entre a requisição e a resposta, como a validação de tokens de autenticação.

A comunicação com o frontend é feita por meio de uma API RESTful.

PRÉ-REQUISITOS
Antes de começar, certifique-se de que você tem o seguinte software instalado em sua máquina:

Node.js e npm: Baixe e instale a versão LTS.

PostgreSQL: Baixe e instale o banco de dados.

Ferramenta de API: O Postman ou o Insomnia são recomendados para testar os endpoints da API.

INSTALAÇÃO E CONFIGURAÇÃO
Siga os passos abaixo para configurar e rodar o projeto em seu ambiente local.

1. INSTALE AS DEPENDÊNCIAS
   Navegue até o diretório raiz do projeto e instale todos os pacotes necessários:

Bash

npm install
2. CONFIGURAÇÃO DO AMBIENTE
   Crie um arquivo chamado .env na raiz do projeto (AgendaParticular/). Este arquivo armazenará informações sensíveis, como as credenciais do banco de dados e a chave secreta para os tokens JWT.

Copie e cole o seguinte conteúdo no arquivo .env, substituindo os valores pelos seus próprios:

DB_NAME=seu_nome_de_banco
DB_USER=seu_usuario
DB_PASSWORD=sua_senha
DB_HOST=localhost
DB_PORT=5432
JWT_SECRET=uma_string_secreta_forte_aleatoria
3. SINCRONIZE O BANCO DE DADOS
   O arquivo app.js irá sincronizar os modelos (tabelas) com o seu banco de dados automaticamente quando o servidor for iniciado. Certifique-se de que o seu serviço PostgreSQL esteja rodando.

4. INICIE O SERVIDOR
   Execute o comando a seguir no terminal para iniciar o backend:

Bash

node app.js
Se tudo estiver correto, você verá no terminal as mensagens de log confirmando que a conexão com o banco de dados foi estabelecida e que o servidor está rodando na porta 5000.

ESTRUTURA DO PROJETO
A organização de pastas do projeto é a seguinte:

AgendaParticular/
├── .env                  # Variáveis de ambiente
├── node_modules/         # Dependências do projeto
├── src/                  # Código-fonte da aplicação
│   ├── config/           # Configurações do banco de dados
│   ├── controllers/      # Lógica de negócio (autenticação, CRUD)
│   ├── middlewares/      # Middleware de autenticação JWT
│   ├── models/           # Modelos de dados Sequelize
│   └── routes/           # Endpoints da API
├── app.js                # Arquivo principal do servidor
├── package.json          # Metadados e dependências do projeto
└── README.md             # Este arquivo
ENDPOINTS DA API
Para testar as funcionalidades, utilize uma ferramenta de API como o Postman para fazer requisições para os seguintes endpoints:

AUTENTICAÇÃO DE USUÁRIOS (/api/auth)
POST /api/auth/register: Registra um novo usuário.

Corpo da Requisição: { "name": "...", "email": "...", "password": "..." }

POST /api/auth/login: Realiza o login do usuário e retorna um JWT.

Corpo da Requisição: { "email": "...", "password": "..." }

EVENTOS (/api/events)
POST /api/events: Cria um novo evento. (Requer JWT no cabeçalho x-auth-token)

GET /api/events: Retorna todos os eventos do usuário logado. (Requer JWT)

PUT /api/events/:id: Atualiza um evento específico. (Requer JWT)

DELETE /api/events/:id: Exclui um evento específico. (Requer JWT)

TAREFAS (/api/tasks)
POST /api/tasks: Cria uma nova tarefa. (Requer JWT)

GET /api/tasks: Retorna todas as tarefas do usuário logado. (Requer JWT)

PUT /api/tasks/:id: Atualiza uma tarefa específica. (Requer JWT)

DELETE /api/tasks/:id: Exclui uma tarefa específica. (Requer JWT)
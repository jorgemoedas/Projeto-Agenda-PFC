const express = require('express');
const { sequelize, connectDB } = require('./src/config/database');
const cors = require('cors');

const authRoutes = require('./src/routes/authRoutes');
const eventsRoutes = require('./src/routes/eventsRoutes');
const tasksRoutes = require('./src/routes/tasksRoutes');

const app = express();

// Sincroniza os modelos com o banco de dados
const syncModels = async () => {
    try {
        await sequelize.sync({ alter: true }); // Use { force: true } para recriar as tabelas (apenas em dev)
        console.log('Modelos sincronizados com o banco de dados.');
    } catch (error) {
        console.error('Erro ao sincronizar modelos:', error);
    }
};

// Inicializa a conexão com o banco de dados
connectDB();
syncModels();

// Middleware
app.use(express.json());
app.use(cors());

// Rotas da API
app.use('/api/auth', authRoutes);
app.use('/api/events', eventsRoutes);
app.use('/api/tasks', tasksRoutes);

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
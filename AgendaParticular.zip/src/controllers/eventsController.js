const Event = require('../models/Event');

// Criar um novo evento
exports.createEvent = async (req, res) => {
    try {
        const { title, description, startDate, endDate } = req.body;
        const newEvent = await Event.create({
            title,
            description,
            startDate,
            endDate,
            userId: req.user.id,
        });
        res.status(201).json(newEvent);
    } catch (error) {
        console.error(error.message);
        res.status(500).send('Erro no Servidor');
    }
};

// Listar todos os eventos do usuário
exports.getEvents = async (req, res) => {
    try {
        const events = await Event.findAll({
            where: { userId: req.user.id },
            order: [['startDate', 'ASC']],
        });
        res.json(events);
    } catch (error) {
        console.error(error.message);
        res.status(500).send('Erro no Servidor');
    }
};

// Atualizar um evento
exports.updateEvent = async (req, res) => {
    try {
        const { title, description, startDate, endDate } = req.body;
        const event = await Event.findOne({ where: { id: req.params.id, userId: req.user.id } });

        if (!event) {
            return res.status(404).json({ msg: 'Evento não encontrado.' });
        }

        event.title = title || event.title;
        event.description = description || event.description;
        event.startDate = startDate || event.startDate;
        event.endDate = endDate || event.endDate;

        await event.save();
        res.json(event);
    } catch (error) {
        console.error(error.message);
        res.status(500).send('Erro no Servidor');
    }
};

// Excluir um evento
exports.deleteEvent = async (req, res) => {
    try {
        const event = await Event.findOne({ where: { id: req.params.id, userId: req.user.id } });

        if (!event) {
            return res.status(404).json({ msg: 'Evento não encontrado.' });
        }

        await event.destroy();
        res.json({ msg: 'Evento removido com sucesso.' });
    } catch (error) {
        console.error(error.message);
        res.status(500).send('Erro no Servidor');
    }
};
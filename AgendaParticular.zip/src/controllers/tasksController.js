const Task = require('../models/Task');

// Criar uma nova tarefa
exports.createTask = async (req, res) => {
    try {
        const { title, description } = req.body;
        const newTask = await Task.create({
            title,
            description,
            userId: req.user.id,
        });
        res.status(201).json(newTask);
    } catch (error) {
        console.error(error.message);
        res.status(500).send('Erro no Servidor');
    }
};

// Listar todas as tarefas do usuário
exports.getTasks = async (req, res) => {
    try {
        const tasks = await Task.findAll({
            where: { userId: req.user.id },
            order: [['createdAt', 'DESC']],
        });
        res.json(tasks);
    } catch (error) {
        console.error(error.message);
        res.status(500).send('Erro no Servidor');
    }
};

// Atualizar uma tarefa
exports.updateTask = async (req, res) => {
    try {
        const { title, description, status } = req.body;
        const task = await Task.findOne({ where: { id: req.params.id, userId: req.user.id } });

        if (!task) {
            return res.status(404).json({ msg: 'Tarefa não encontrada.' });
        }

        task.title = title || task.title;
        task.description = description || task.description;
        task.status = status || task.status;

        await task.save();
        res.json(task);
    } catch (error) {
        console.error(error.message);
        res.status(500).send('Erro no Servidor');
    }
};

// Excluir uma tarefa
exports.deleteTask = async (req, res) => {
    try {
        const task = await Task.findOne({ where: { id: req.params.id, userId: req.user.id } });

        if (!task) {
            return res.status(404).json({ msg: 'Tarefa não encontrada.' });
        }

        await task.destroy();
        res.json({ msg: 'Tarefa removida com sucesso.' });
    } catch (error) {
        console.error(error.message);
        res.status(500).send('Erro no Servidor');
    }
};